# O Orquestrador · logos para a área de membros

Cópias leves (abaixo de 0,3 MB) tiradas do kit oficial. O kit oficial é a fonte e fica em:

`/Volumes/SSD EXTERNO/ORAYON/AGENCY MACHINE/INFO DA MARCA/03-Marca/Identidade/final/orquestrador`

O logo nunca é redesenhado, recolorido nem recebe sombra: use sempre estes arquivos.
