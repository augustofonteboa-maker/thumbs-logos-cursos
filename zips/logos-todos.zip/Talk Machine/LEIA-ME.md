# Talk Machine · logos para a área de membros

Cópias leves (abaixo de 0,3 MB) tiradas do kit oficial. O kit oficial é a fonte e fica em:

`/Volumes/SSD EXTERNO/ORAYON/TALK MACHINE/EXPORTAR`

O logo nunca é redesenhado, recolorido nem recebe sombra: use sempre estes arquivos.
